RL Tracker v1.0.0 — pierwsze wydanie

Dashboard zachowuje karty MMR, kalendarz, wykres świecowy, historię meczów, statystyki sesji, rozkład MMR i tryby gry.
Lewy pasek: Dashboard, Analiza, Kalendarz, Ustawienia.
Cele MMR: ręczne wpisywanie aktualnego i docelowego MMR, procent postępu.
6 motywów: Obsidian, Cyberpunk, Midnight Ocean, Inferno, Matrix, Arctic Frost.
Usunięto integrację automatycznego MMR. MMR pozostaje ręczne.
Dane zapisują się pod dotychczasowym kluczem rltracker23. Przed aktualizacją zrób Eksport JSON.
Budowanie: npm install, npm run dist. Instalator w dist.
