const {contextBridge,ipcRenderer}=require('electron');contextBridge.exposeInMainWorld('rocketStats',{onMessage:fn=>ipcRenderer.on('rl-stats',(_e,m)=>fn(m))});
