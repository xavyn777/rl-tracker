const {app,BrowserWindow}=require('electron');
const net=require('net');
let socket=null, retry=null, win=null;
function emit(type,data){if(win&&!win.isDestroyed())win.webContents.send('rl-stats',{type,data})}
function connectStats(){if(socket){socket.destroy();socket=null;}let buf='';const client=net.connect({host:'127.0.0.1',port:49123});socket=client;client.setTimeout(20000);client.on('connect',()=>emit('status','Połączono z Rocket League'));client.on('data',chunk=>{buf+=chunk.toString('utf8');if(buf.length>2000000){buf='';return;}let pos;while((pos=buf.indexOf('\n'))>=0){const line=buf.slice(0,pos).trim();buf=buf.slice(pos+1);if(!line)continue;try{const obj=JSON.parse(line);if(obj&&obj.Event)emit('event',obj)}catch(e){}}});client.on('error',()=>emit('status','Oczekiwanie na Rocket League / Stats API'));client.on('timeout',()=>client.destroy());client.on('close',()=>{if(socket===client)socket=null;clearTimeout(retry);retry=setTimeout(connectStats,3000)});}

function create(){const w=new BrowserWindow({width:1540,height:980,minWidth:1000,minHeight:680,backgroundColor:'#080d12',webPreferences:{nodeIntegration:false,contextIsolation:true,preload:require('path').join(__dirname,'preload.js')}});win=w;w.loadFile('index.html');w.webContents.once('did-finish-load',()=>connectStats());w.setMenuBarVisibility(false)}
app.whenReady().then(create);app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)create()});
