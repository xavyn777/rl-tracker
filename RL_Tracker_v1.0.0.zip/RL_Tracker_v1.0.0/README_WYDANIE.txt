RL Tracker v1.0.0 — pierwsze wydanie

Zawiera aktualne funkcje z poprzedniej wersji: Dashboard, Analiza, Kalendarz, Ustawienia, motywy, zapis sesji i statystyki.
Aby zbudować instalator na Windows: uruchom BUILD_WINDOWS.bat. Instalator powstanie w folderze dist.
