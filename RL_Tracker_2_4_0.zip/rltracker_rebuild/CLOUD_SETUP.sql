-- Uruchom w Supabase SQL Editor. Włącz Email auth w Authentication.
create table if not exists public.rltracker_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.rltracker_profiles enable row level security;
create policy "Read own profile" on public.rltracker_profiles for select to authenticated using ((select auth.uid()) = user_id);
create policy "Insert own profile" on public.rltracker_profiles for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "Update own profile" on public.rltracker_profiles for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
