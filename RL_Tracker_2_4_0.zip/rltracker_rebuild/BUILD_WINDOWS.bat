@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Zainstaluj Node.js LTS z nodejs.org & pause & exit /b 1)
call npm install
if errorlevel 1 (echo Blad npm install & pause & exit /b 1)
call npm run dist
if errorlevel 1 (echo Blad budowania & pause & exit /b 1)
echo GOTOWE! Sprawdz folder dist.
pause
