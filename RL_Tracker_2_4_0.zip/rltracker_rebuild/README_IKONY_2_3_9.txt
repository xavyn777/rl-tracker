Ikony rang: InGameRank (github.com/nixvio64/InGameRank), folder Tiers, pliki 1.png–22.png. Zachowano oryginalne grafiki bez modyfikacji. Licencja źródła: patrz repozytorium InGameRank.
