const {app,BrowserWindow}=require('electron');
function create(){const w=new BrowserWindow({width:1540,height:980,minWidth:1000,minHeight:680,backgroundColor:'#080d12',webPreferences:{nodeIntegration:false,contextIsolation:true}});w.loadFile('index.html');w.setMenuBarVisibility(false)}
app.whenReady().then(create);app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)create()});
