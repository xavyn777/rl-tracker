RL Tracker 2.3.3 — 22 newly drawn original rank-inspired PNG icons with transparent backgrounds. These are custom designs, not official Rocket League assets. Rebuild with BUILD_WINDOWS.bat.
