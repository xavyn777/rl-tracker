RL Tracker 2.3.5

1. BUILD_WINDOWS.bat (wymaga Node.js LTS).
2. Installer znajdziesz w dist.
3. Brak danych demonstracyjnych. MMR wpisujesz sam w Ustawieniach.
4. Wykres świecowy powstaje po dodaniu meczów.
5. Konto między urządzeniami: załóż własny projekt na supabase.com, w SQL Editor uruchom CLOUD_SETUP.sql, skopiuj Project URL i publiczny anon/publishable key do Ustawień RL Tracker. Następnie zarejestruj konto i potwierdź e-mail. Na drugim komputerze wprowadź te same ustawienia Supabase i zaloguj się tym samym kontem.
6. Nie wklejaj klucza service_role/secret do aplikacji.
7. Dane synchronizowane są w trybie last-write-wins, nie edytuj równocześnie na kilku urządzeniach.
8. Ikony wycięte z obrazu referencyjnego przesłanego w rozmowie.
9. Rangi i dywizje są szacowane z podanych tabel, bez oficjalnego API.

10. Analiza: dodawanie zbiorczych wygranych/przegranych per tryb. Nie zmienia MMR; dane są przechowywane lokalnie i w eksporcie JSON.
11. Grafiki rang w tej paczce są nadal nieoficjalne; nie udało się pobrać oryginalnych plików.
